package consolecrm;

public class Menu {
    
    // TODO CLASSES
    
}
