package consolecrm;
import java.util.Scanner;

public class ConsoleCRM {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Username: ");
        String username = sc.nextLine();
        System.out.print("Password: ");
        String password = sc.nextLine();
        System.out.print("Select permission: ");
        int permission = Integer.parseInt(sc.nextLine());
        
        User user = new User();
        user.setUserName(username);
        user.setPassword(password);
        if (int = 1) {
                        
        }
    }
    
}
