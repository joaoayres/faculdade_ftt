package consolecrm;

import java.io.FileWriter;
import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;

public class User {
    
    private String userName;
    private String password;
    public enum Permission{
        SALES, MANAGEMENT, ADMINISTRATOR;
    }
    private Permission permission;
    
    public String getUserName() {
    return userName;
    }
    
    public void setUserName(String newUserName) {
    this.userName = newUserName;
    }
    
    public String getPassword() {
    return password;
    }
    
    public void setPassword(String newPassword) {
    this.password = newPassword;
    }
    
    public void setPermission(int option) {
        if(option == 1){
            permission = Permission.SALES;
        }
        else if(option == 2) {
            permission = Permission.MANAGEMENT;
        }
        else
            permission = Permission.ADMINISTRATOR;
    }
    
    public String getPermission() {
        return permission.toString();
    }
    
    public void createJSONUser(User user) throws JSONException{
        JSONObject userDetails = new JSONObject();
        userDetails.put("username", user.getUserName());
        userDetails.put("password", user.getPassword());
        userDetails.put("permission", user.getPermission());
        
        JSONObject userObject = new JSONObject();
        userObject.put("user", userDetails);
        
        try (FileWriter userFile = new FileWriter("users.json")) { 
            userFile.write(userObject.toJSONString());
            userFile.flush();
 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
